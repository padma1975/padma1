package com.padma.olx.service;

import java.util.List;

import com.padma.olx.model.User;
public interface UserService { 
	public List<User> getAllUsers();
//public User createUser (Long id);
public String loginUser(User user); 
public User registerUser(User user);
public User getUser(int id);
public boolean logoutUser(int id);
User Regitration(User user);
String authuntication(User user);
public String loginUser(String username, String password);
}

