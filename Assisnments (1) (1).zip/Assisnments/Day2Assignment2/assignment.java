
import java.util.Scanner;

class Student {
	
	int studentId;
	String studentName;
	private  String studentAddress;
	private String collegeName;
	
	Student(int studentId,String studentName, String studentAddress )
	{
		this.studentId=studentId;
		this.studentName=studentName;
		this.studentAddress=studentAddress;
	}
	Student(int studentId,String studentName, String studentAddress , String collegeName)
	{
		this( studentId, studentName, studentAddress);
		this.collegeName=collegeName;
		
	}
}


public class assignment1 {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		

		System.out.println("Enter Student's Id: ");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter Student's Name:");
		String name=sc.nextLine();
		System.out.println("Enter Student's address");
		String address=sc.nextLine();

	
		System.out.println("Whether the student is from NIT(Yes/No)");
		String collegeName=sc.nextLine();
		if(collegeName.contains("yes") || collegeName.contains("YES") )
		{
			
			Student s=new Student(id,name,address);
			System.out.println("Student Id: "+ s.studentId);
			System.out.println("Student Name: "+ s.studentName);
			System.out.println("Student Id: "+ s.studentId);
		}
		else if(collegeName.contains("no") || collegeName.contains("NO") ) {
			
			System.out.println("Enter the college name:");
			String college=sc.nextLine();
			Student s=new Student(id,name,address,college);
			
		}
		else
		{
			System.out.println("Wrong Input");
		}

	}

}
