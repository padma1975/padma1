package exercise;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class UserMain{
	Driver d=new Driver();
	String name;
	String panNumber;
	void getInput() {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter your name: ");
	name=sc.nextLine();
	System.out.println("Enter your PAN Number: ");
	panNumber=sc.nextLine();
	
	d.validate(panNumber);
	}
	
}

public class Driver {

	
	public static void validate(String source)
	{boolean found=false;
		
		String regex="[A-Z]{5}[0-9]{4}[A-Z]{1}";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(source);
		if(m.matches())
		{
			System.out.println("Valid PAN Number");
			found=true;
		}
		if(!found)
		{
			System.out.println("Invalid PAN Number");
		}
	}
	
	public static void main(String[] args) {
		UserMain  m=new UserMain();
		m.getInput();

	}

}
