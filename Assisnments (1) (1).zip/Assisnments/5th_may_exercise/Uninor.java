package exer2;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Objects;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

class Employee{
	
	@Override
	public String toString() {
		return "Employee [name=" + name + ", panno=" + panno + ", emailid=" + emailid + ", salary=" + salary + "]";
	}
	private String name;
	private String panno;
	private String emailid;
	private int salary;
	@Override
	public int hashCode() {
		return Objects.hash(emailid, name, panno, salary);
	}


	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Employee other = (Employee) obj;
		return Objects.equals(emailid, other.emailid) && Objects.equals(name, other.name)
				&& Objects.equals(panno, other.panno) && salary == other.salary;
	}

	
	public Employee(String name, String panno, String emailid, int salary) {

		this.name = name;
		this.panno = panno;
		this.emailid = emailid;
		this.salary = salary;
	}

	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPanno() {
		return panno;
	}
	public void setPanno(String panno) {
		this.panno = panno;
	}
	public String getEmailid() {
		return emailid;
	}
	public void setEmailid(String emailid) {
		this.emailid = emailid;
	}
	public int getSalary() {
		return salary;
	}
	public void setSalary(int salary) {
		this.salary = salary;
	}
	
	
}
class operation{
	List<Employee> list=new ArrayList<>();

	void validation(String name,String panNumber,String email, int salary)
	{	boolean found=false;
		
		Employee emp=new Employee(name,panNumber,email,salary);
		
		if(list.isEmpty())
		{
			list.add(emp);
			found=true;
		}
		
		else 
		{
			for(Employee e:list)
			{
				if(e.getEmailid().equals(email) )
				{
					System.out.println(name+" is an existing customer");
				
					found=true;
					break;
					
				}
				else if(e.getPanno().equals(panNumber))
				{
					System.out.println(name+" is an existing customer");
					
					found=true;
					break;
				}
				
			}
			
			if(found==false)
			{
				list.add(emp);
			}
		}
		
	}
	
	
	void displayResult()
	{
		for(Employee ee:list)
		{
			System.out.println(ee);
		}
	}
	
}





public class Uninor {
	String name;
	String panNumber;
	String email;
	int salary;
	public static void main(String[] args) throws InputMismatchException{
		//Main Method Started
		Scanner sc=new Scanner(System.in);
		int input;
		operation op=new operation();
		do
			{Uninor u=new Uninor();
		u.userInput();
		validatePancard(u.panNumber);
		
		op.validation(u.name,u.panNumber,u.email,u.salary);
		
		System.out.println("press 1 to add next customer details or press any digit to exit the program ");
		 input=sc.nextInt();
			}while(input==1);
		
              op.displayResult();
//Main Method Ended
	}
	
	void userInput() 
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter your Name: ");
		 name=sc.nextLine();
		System.out.println("String Enter your Pan Number");
		 panNumber=sc.nextLine();
		System.out.println("Enter your Email ID: ");
		 email=sc.nextLine();
		System.out.println("Enter your salary: ");
		salary=sc.nextInt();
	}

	public static void validatePancard(String source)
	{
		boolean found=false;		
		String regex="[A-Z]{5}[0-9]{4}[A-Z]{1}";
		Pattern p=Pattern.compile(regex);
		Matcher m=p.matcher(source);
		if(m.matches())
		{
			System.out.println("Valid PAN Number");
			found=true;
		}
		if(!found)
		{
			System.out.println("Invalid PAN Number");
		}
	}
	
}
