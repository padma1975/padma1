package assignment2;

import java.util.Scanner;

public class exceptionHandlingAssignment {

	public static void main(String[] args) {
	     Scanner sc=new Scanner(System.in);
	     double feet;
	     double inch;
	     double fc;
	     double ic;
		
		try {
			System.out.println("Enter the length in feet");
			feet=sc.nextDouble();
			System.out.println("Enter the length in inches");
			inch=sc.nextDouble();
			if(feet>0 && inch>0)
			{
			fc=feet*30.48;
			ic=inch*2.54;
			System.out.println("Feet to Centimeter conversion : "+fc);
			System.out.println("Inches to Centimeter conversion : "+ic);
			}
			else
			{
				Exception exception = null;
				throw exception;
			}
			
			
			
		}
		
		catch (Exception e)
		{
			System.out.println("Invalid input detected");
		}

	}

}
