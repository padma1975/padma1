package assignment1;

import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Scanner;
import static java.nio.file.StandardOpenOption.*;

import java.io.BufferedOutputStream;
import java.io.BufferedWriter;
import java.io.IOException;
import java.io.OutputStream;
import java.io.OutputStreamWriter;

class Patient{
	int id;
	String name;
	double balance;
	public Patient(int id, String name, double balance) {
		
		this.id = id;
		this.name = name;
		this.balance = balance;
	}
	
}


public class writePatientrecords {
	
	public static void main(String[] args) {
		
		Path file=Paths.get("D:\\Training\\zensar\\Programs\\JavaWorkspace\\assignment1\\patientRecord.txt");
		String data;
		
	try {
		OutputStream Output = new BufferedOutputStream(Files.newOutputStream(file, APPEND));
		BufferedWriter bw=new BufferedWriter(new OutputStreamWriter(Output));
		
		
		Scanner sc=new Scanner(System.in);
		int id;
		String name;
		double balance;
		System.out.println("Enter Patient ID: ");
		id=sc.nextInt();
		String delimiter=",";
		while(id!=0)
		{
		
			System.out.println("Enter Patient Name: ");
			sc.nextLine();
			name=sc.nextLine();
			
			System.out.println("Enter balance :");
			balance=sc.nextDouble();
			
			data=id+delimiter+name+delimiter+balance;
			bw.write(data);
			bw.newLine();
			System.out.println("Enter next patient to add or 0  to quit");
			id=sc.nextInt();
		}
		bw.close();
		
	
		
	} catch (IOException e) {
		
		e.printStackTrace();
	}

	



 
	}

	
	
	
}

