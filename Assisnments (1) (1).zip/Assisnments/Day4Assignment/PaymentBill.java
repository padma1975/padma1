package Day4Assignment;

import java.util.Scanner;

class Bill{
	

	void processPayment(double Payment)
	{
		System.out.println(Payment +" has been Deducted successfuly....");
	}
}
class Payment extends Bill {
	private double amount;
	boolean payAmount()
	 {  
		if(amount>0)
		{
			return true;
		}
		else
		{
			return false;
		}
		 
	 }
}
class Cheque  extends Payment{
	 private int checkno;
	 String date_of_issue;
	 private double amount;
	 
	 public Cheque(int checkno, double amount) {
		
		this.checkno = checkno;
		this.amount = amount;
	}

		void payAmount(int date)
		{

		  
		    if(date==04 || date==03 || date==02 || date==01 || date==12 || date==11  )
		    {
		    	System.out.println("Payment sucess....");
		    	processPayment(amount);
		    }
		    else
		    {
		    	System.out.println(" your cheque is expired amount can't be paid");
		    	amount=0;
		    }
	}
}
class Cash  extends Payment{
	double amount;
	public Cash(double amount2) {
		amount=amount2;
	}
	boolean payAmount()
	{
		if(amount>0)
		{
			System.out.println("Payment sucess....");
			return true;
		}
		else
		{
			return false;
		}
		
	}
}
class Credit  extends Bill  {
	private int credit_card_no;
	String  card_type;
	private double credit_card_amount;
	
	double tax;
	
	public Credit(int card, String cardType, double amount) {
		credit_card_no=card;
		card_type=cardType;
		credit_card_amount=amount;
		
		
		
		if(card_type=="silver")
		{
			tax=credit_card_amount*0.02;
		
		}
		else if(card_type=="gold")
		{
			tax=credit_card_amount*0.05;
			
		}
		else if(card_type=="platinum")
		{
			tax=credit_card_amount*0.1;
			
		}
	}
		
	
	
	
	double  payAmount()
	{
		
	  return  credit_card_amount=credit_card_amount-tax;
		
	}
	void paymentStatus()
	{
		System.out.println("Payment sucess....");
		
	}
}


public class PaymentBill {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("press 1 to pay amount by Cheque :");
	System.out.println("press 2 to pay amount by Cash :");
	System.out.println("press 3 to pay amount by Credit card :");
	
	int n=sc.nextInt();
	if(n==1)
	{
	
		System.out.println("Enter  check number : ");
		int checknum=sc.nextInt();
		System.out.println("Enter  issued day");
		int day=sc.nextInt();
		System.out.println("Enter  issued month");
		int date=sc.nextInt();
		System.out.println("Enter  issued year");
		int year=sc.nextInt();
		
		sc.nextLine();
		
	    System.out.println("Enter  amount  : ");
	    double amount=sc.nextDouble();
		Cheque c=new Cheque(checknum,amount);
		c.payAmount(date);
		
		
		
	    
	}
	
	else if(n==2)
	{
		System.out.println("Enter  amount  :");
		double amount=sc.nextDouble();
		Cash c=new Cash(amount);
		c.processPayment(amount);
		
		
	}
	else if(n==3)
	{
		System.out.println("Enter Credit Card Number : ");
		int card=sc.nextInt();
		
		
		System.out.println("select your card Type");
		System.out.println("Enter 1 : Silver");
		System.out.println("Enter 2 : gold");
		System.out.println("Enter 3 : platinum");
		int input=sc.nextInt();
		
		Credit crd;
		if(input==1)
		{
			 System.out.println("Enter  amount  : ");
			  double amount=sc.nextDouble();
			  if(amount<=10000)
			  {
				  crd=new Credit(card,"silver",amount);
				  crd.paymentStatus();
				  double result=crd.payAmount();
				  crd.processPayment(result);
			  }
			  else
			  {
				  System.out.println("Maximum you can draw up to 10000 ");
			  }
		}
		else if(input==2)
		{
			 System.out.println("Enter amount  : ");
			    double amount=sc.nextDouble();
			    if(amount<=50000)
				  {
			    	crd=new Credit(card,"gold",amount);
			    	  crd.paymentStatus();
			    	  double result=crd.payAmount();
					  crd.processPayment(result);
				  }
				  else
				  {
					  System.out.println("Maximum you can draw up to 50000 ");
				  }
			    
		}
		else if(input==3)
		{
			 System.out.println("Enter amount  : ");
			    double amount=sc.nextDouble();
			    if(amount<=100000)
				  {
			    	crd=new Credit(card,"platinum",amount);
			    	  crd.paymentStatus();
			    	  double result=crd.payAmount();
					  crd.processPayment(result);
				  }
				  else
				  {
					  System.out.println("Maximum you can draw up to 100000 ");
				  }
		}
		else
		{
			System.out.println("enter a valid key ");
		
		}
		
		
	
		
	}
	else
	{
		System.out.println("please enter a valid key");
	}

	}

}
