package Day3Assignment;

import java.util.Scanner;

class Order{
	public int OrderNumber;
	public String CustomerName;
	public int Quantity;
	double price=19.95;
	
	public Order(int orderNumber, String customerName, int quantity) {
		
		OrderNumber = orderNumber;
		CustomerName = customerName;
		Quantity = quantity;
	}
	double CalculateTotalPrice()
	{
		return price*Quantity;
	}

	
public String toString()
{
	return "Customer Name : "+CustomerName+"\n"+"Quantity: "+Quantity;
}
	
	

public int hashCode(){
	return OrderNumber;
	
}
public boolean equals(Object obj)
{
	Order ord=(Order)obj;
if(OrderNumber==ord.OrderNumber)
{
	return true;
}
else
{
	return false;
}
	
}
public class ProductOrder {

	public static void main(String[] args) {
		
		
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter your Name");
		String cname=sc.nextLine();
		System.out.println("Enter your order number");
		int onumber=sc.nextInt();
		System.out.println("Enter the Quantity");
		int quantity=sc.nextInt();
	
		

		Order o1 =new Order(onumber,cname,quantity);
		Order o2 =new Order(onumber,cname,quantity);
		System.out.println("Order Number :"+o1.hashCode());
        System.out.println(o1.toString());
        System.out.println("Total Price :"+o1.CalculateTotalPrice());
        
        System.out.println("********************************");
        
		System.out.println("Order Number :"+o2.hashCode());
        System.out.println(o2.toString());
        System.out.println("Total Price :"+o2.CalculateTotalPrice());
        
        System.out.println("********************************");
        
        System.out.println(o1.equals(o2));
        
       
        
	}
	}

}
