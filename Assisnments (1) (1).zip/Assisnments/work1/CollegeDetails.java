package work1;

import java.util.Scanner;

class Person{
	private String firstName;
	private String lastName;
	private String streetaddress;
	private int zipCode;
	private int phoneNumber;
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getStreetaddress() {
		return streetaddress;
	}
	public void setStreetaddress(String streetaddress) {
		this.streetaddress = streetaddress;
	}
	public int getZipCode() {
		return zipCode;
	}
	public void setZipCode(int zipCode) {
		this.zipCode = zipCode;
	}
	public int getPhoneNumber() {
		return phoneNumber;
	}
	public void setPhoneNumber(int phoneNumber) {
		this.phoneNumber = phoneNumber;
	}
	
	void displayDetails()
	{
		System.out.println(" First Name : "+firstName);
		System.out.println(" Last Name : "+lastName);
		System.out.println("Street Address : "+streetaddress);
		System.out.println(" Zip Code : "+zipCode);
		System.out.println("Phone Number : "+phoneNumber);
	}
	
}

class CollegeEmployee extends Person{
	
	int SSN;
	double annualSalary;
	String departmentName;
	
	public CollegeEmployee(int sSN, double annualSalary, String departmentName) {
		
		SSN = sSN;
		this.annualSalary = annualSalary;
		this.departmentName = departmentName;
	}



	
	
	void displayDetails()
	{
		System.out.println("Annual Salary :"+annualSalary);
		System.out.println("Department :"+departmentName);
		
	}
}
class Faculty extends Person{
	Scanner sc1=new Scanner(System.in);
	
	String [] courses;
	
	
	void displayDetails( String [] courses)
	{
		System.out.println("Entered courses are : ");
      for (int i=0;i<courses.length;i++)
			
		{
			System.out.println(courses[i]);
			
		}
		
	}
}

public class CollegeDetails {
	Scanner sc=new Scanner(System.in);

	public static void main(String[] args) {
		String fname ;
		String lname;
		String addr;
		int zcode;
		int phone;
Scanner sc=new Scanner(System.in);


Person[] p=new Person[2];
for(int k=0;k<p.length;k++)
{
	p[k]=new Person();
	sc.nextLine();
	
System.out.println("Eneter your first name");
 fname=sc.nextLine();
System.out.println("Eneter your last name");
 lname=sc.nextLine();
System.out.println("Eneter your address");
 addr=sc.nextLine();
System.out.println("Eneter your zipCode");
zcode=sc.nextInt();
System.out.println("Eneter your phone number");
 phone=sc.nextInt();
	p[k].setFirstName(fname);
	p[k].setLastName(fname);
	p[k].setStreetaddress(addr);
	p[k].setZipCode(zcode);
	p[k].setPhoneNumber(phone);
		
	



System.out.println("press C for CollegeEmployee or F  for  Faculty to enter");
System.out.println("Press Q to Qiut");
char ch=sc.next().charAt(0);
if(ch=='C' || ch=='c')
{
	System.out.println("Enter your SSN number");
	int ssn=sc.nextInt();
	sc.nextLine();
	System.out.println("Enter your Annual Salary");
	double salary=sc.nextDouble();
	sc.nextLine();
	System.out.println("Enter your Department Name");
	String  department=sc.nextLine();
	
	Person p1=new CollegeEmployee(ssn,salary,department);
	CollegeEmployee emp=(CollegeEmployee)p1;
	Person ppp=new Person();
	ppp.displayDetails();
	emp.displayDetails();
	
}
else if(ch=='F' || ch=='f')
{


	System.out.println("Enter how many of course you want to enter");
	int course=sc.nextInt();
	String[] courses=new String[course];
	for (int j=0;j<course;j++)
		
	{
		sc.nextLine();
		System.out.println("Enter course : "+(j+1));
		
		courses[j]=sc.nextLine();
	}
	Person p2=new Faculty();
	Person pp=new Person();
	Faculty ff= (Faculty)p2;
	pp.setFirstName(fname);
	pp.setLastName(fname);
	pp.setStreetaddress(addr);
	pp.setZipCode(zcode);
	pp.setPhoneNumber(phone);
	pp.displayDetails();
	ff.displayDetails( courses);
}



	


else if(ch=='Q' || ch=='q')
{
	System.out.println("u quited");
}
}
	}
}


