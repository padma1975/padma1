package assignment;
import java.util.*;

class Student{
	Scanner sc =new Scanner(System.in);
	private int id;
	private String name;
	private int[] marks;
	private int average;
	private char grade;
	
	
	int total=0;
	
	Student(int id , String name)
	{
		this.id=id;
		this.name=name;
	}
	public void calculateAvg(int[] sub) {
		
		for(int i=0;i<sub.length;i++)
		{
			total+=sub[i];
		}
		average=total/sub.length;
		
	
	}
	
	
	public void finalGrade(int[] sub)
	{
		
		for(int i=0;i<sub.length;i++)
		{
			if(sub[i]<50)
			{
			 grade='F';
			}
		}
		
	 if(average>80 && average<100)
		{
			grade='O';
		}
		else 
		{
		grade='A';
		}
	 
	}
	
	public void display()
	{
		System.out.println("Id: "+id);
		System.out.println("Name: "+name);
		System.out.println("Average: "+average);
		System.out.println("Grade: "+grade);
	}
	
}

public class SGC {

	public static void main(String[] args) {
		Scanner sc =new Scanner(System.in);
		System.out.println("Enter the Id");
		int id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter the Name");
		String name=sc.nextLine();
		int temp;
		Student s =new Student(id,name);
		
		System.out.println("Enter the no. of subjects:");
			int subject=sc.nextInt();
			if( subject>0)
			{
		int sub[]=new int[subject];
			
			for(int i=0;i<subject;i++)
			{
				System.out.println("Enter mark for subject "+(i+1)+":");
				temp=sc.nextInt();
				if(temp>=0 && temp<=100)
				{
					sub[i]=temp;
				}
				
			}
		
		
		s.calculateAvg(sub);
		s.finalGrade(sub);
		s.display();
		}
		else
		{
			System.out.println("Invalid number of subject :");
		
	  
		}
		
		
	}
	

}
