package customerDetailsAssignment;

import java.util.*;

class Customer{
	private int customerId;
	private String customerName;
	private String emailId;
	private long phoneNo;
	
	public int getCustomerId() {
		return customerId;
	}
	public void setCustomerId(int customerId) {
		this.customerId = customerId;
	}
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public long getPhoneNo() {
		return phoneNo;
	}
	public void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}
	@Override
	public String toString() {
		return "Customer : [customerId=" + customerId + ", customerName=" + customerName + ", emailId=" + emailId
				+ ", phoneNo=" + phoneNo + "]";
	}


	}


class CustomerUtility{
	
	List<Customer>  customerList=new ArrayList<>();
	
	public Customer createCustomerDetails(int id ,String name,String email,long phone)
	{
		Customer c=new Customer();
		c.setCustomerId(id);
		c.setCustomerName(name);
		c.setEmailId(email);
		c.setPhoneNo(phone);
		
		return c;
		
		
		
	}
	
	
	boolean addCustomer(Customer cust)
	{
		boolean found=false;
		boolean flag=true;
		if(customerList.isEmpty())
		{
			found =customerList.add(cust);
			return found;
			
		}
		else
		{
			for(Customer c:customerList)
			{
				if((c.getCustomerId()==cust.getCustomerId()))
				{
					System.out.println("ID can not be duplicate");
					flag=false;
					break;
				}
				else if((c.getPhoneNo()==cust.getPhoneNo()))
				{
					System.out.println("phone number can not be duplicate");
					flag=false;
					break;
				}
				else if((c.getEmailId()==cust.getEmailId()))
				{
					System.out.println("email ID can not be Duplicate ");
					flag=false;
					break;
				}
				
			}
			if(flag)
			{
				found=customerList.add(cust);
				
			}
		}
		return found;
	}
	void getCustomer(int id)
	{
		boolean found=false;
		for(Customer cc:customerList)
		{
			if(cc.getCustomerId()==id)
			{
				System.out.println(cc);
				found=true;
				break;
				
			}
			
		}
		if(!found)
		{
		System.out.println("Entered ID is not exist");
		}
		
	}
	 void deleteCustomer(int id)
	{
	boolean found=false;
		
		for(Customer c:customerList)
		{
			if(id==c.getCustomerId())
			{
				
				customerList.remove(c);
				found =true;
				break;
				
			}
		}
		if(!found)
		{
		System.out.println("Entered ID is not exist");
		}
		


	}
	void updateCustomerPhoneNumber(int id ,long phoneNumber)
	{
		boolean flag=true;
		
		for(Customer c:customerList)
		{
			if(c.getCustomerId()==id)
			{
				flag=false;
				c.setPhoneNo(phoneNumber);
				
				
				getAllCustomers();
				break;
				
				
			}
			
		}
		if(flag)
		{
			System.out.println("Entered ID is not exist");
			
		}
		
		
		
	}
		


	long getCustomerPhoneNumber(int id)
	{
		long result=0;
		boolean found =true;
		for(Customer c:customerList)
		{
			if(c.getCustomerId()==id)
			{
				result= c.getPhoneNo();
				found=false;
				
				break;
			}
		
		}
		if(found)
		{
			System.out.println("Entered ID is not exist");
		}
		return result;
		
	}
	void getAllCustomers()
	{
		for(Customer c:customerList)
		{
			System.out.println(c);
		}
	}
}

public class Driver {
	Scanner sc=new Scanner(System.in);
	int addCustomer;
	int phoneNumber;
	int deleteCustomer;
	int displayAllDetails;
	int displaySingleId;
	int exit;

	
	int id;
	String name;
	String email;
	long phone;
	int pdt;
	
	int in;
	
	int count=0;
	long number;
	CustomerUtility utility =new CustomerUtility();
	
	public static void main(String[] args) {
		
		Scanner sc=new Scanner(System.in);
	
		Driver input = new Driver();
		input.menuDisp();
	
		
		
		
		
	
		
		

}
	void menuDisp()
	{
		menu();
		int choice=sc.nextInt();
		switchOperation(choice);
	}
	
	void switchOperation(int swt)
	{
		switch(swt)
		{
		
		case 1:
			do
				{addCustomer();
		   Customer cust=utility.createCustomerDetails(id,name,email,phone);
	                   utility.addCustomer(cust);
	                   System.out.println("press 1 to add next details or enter any digit to end adding details");
	                   in=sc.nextInt();
	                   
	                   ++count;
				}while(in==1);
		
	                   utility.getAllCustomers();
		
			menuDisp();
			break;
	                  
			  
		case 2:addPhoneNumber();
		     utility.updateCustomerPhoneNumber(id,phone);
		    
		     menuDisp();
		     break;
			   
		case 3:System.out.println("Enter ID : ");
		  
		  int k=sc.nextInt();
		       utility.deleteCustomer(k);
		       utility.getAllCustomers();
		       menuDisp();
				break;
			  
			   
		case 4:utility.getAllCustomers();
		menuDisp();
		break;
			   
		case 5:System.out.println("Enter Customer ID to Search Details :");
		int serch=sc.nextInt();
		       utility.getCustomer(serch);
		       menuDisp();
				break;
			   
		case 6:System.out.println("Enter Customer ID to Get Phone Number :");
		int serch1=sc.nextInt();
		       number=utility.getCustomerPhoneNumber(serch1);
		       System.out.println("Mobile No. : "+number);
		       menuDisp();
				break;
			   
		case 7:
			System.out.println("U quited the program : ");
			   break;
			   
			   
	     default: System.out.println("Please enter a valid key");
	}
	}
	void menu()
	{	System.out.println(" ");
		System.out.println("***Enter your Choice***");
		System.out.println(" ");
		System.out.println("Press 1 to Add Customer : ");
		System.out.println("Press 2 to Update Phone Number : ");
		System.out.println("Press 3 to Delete a customer : ");
		System.out.println("Press 4 to Display all the customer : ");
		System.out.println("Press 5 to Display Customer Details for single id : ");
		System.out.println("Press 6 to get Customer Phone Number : ");
		System.out.println("Press 7 to Quit the program");
		
	}
	void addCustomer()
	{
		System.out.println("Enter customer Id : ");
		id=sc.nextInt();
		sc.nextLine();
		System.out.println("Enter customer Name : ");
		name=sc.nextLine();
		System.out.println("Enter customer Email Id : ");
		email=sc.nextLine();
		System.out.println("Enter phone Number : ");
		phone=sc.nextLong();
			
	}
	void addPhoneNumber()
	{
		System.out.println("Enter customer Id  : ");
		id=sc.nextInt();
		System.out.println("Enter your New Phone Number to update ");
		phone=sc.nextLong();
	}
	void getId()
	{
		System.out.println("Enter Customer Id  to Delete Data ");
		
		int id=sc.nextInt();
	}
}
