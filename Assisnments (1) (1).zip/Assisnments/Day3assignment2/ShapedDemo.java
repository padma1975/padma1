package Day3assignment2;

import java.util.Scanner;

abstract class  GeometricFigure{
	double height;
	double width;
	double area;
	
	 void set(double height, double width)
	{
		 this.height = height;
	     this.width = width;
	}
	 void get()
	 {
		 System.out.println("Height : "+height);
		 System.out.println("Width : "+width);
		
	 }
	
	
	


	abstract void ComputeArea();
	
}
class Rectangle extends GeometricFigure{


	public Rectangle(double ht, double wt) {
		height = ht;
	     width = wt;
	}

	public Rectangle(double ht) {
	height=ht;
	width=ht;
	}

	@Override
	void ComputeArea() {

		area= height * width;
	}
}
class Square extends GeometricFigure{
     Square(double ht,double wt)
     {
    	 height = ht;
	     width = wt;
     }
     
   
	@Override
	
	void ComputeArea() {
		area = height*width;
	System.out.println("Area of Square :"+area);
		
	}
	
	
}
class Triangle extends GeometricFigure{

	public Triangle(double ht, double wt) {
		height = ht;
	     width = wt;
	}

	@Override
	void ComputeArea() {
		area=(0.5)*(height*width);
		System.out.println("Area of Triangle :"+area);
		
	}
	
	
}

public class ShapedDemo {

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);
	System.out.println("Enter height");
	double ht=sc.nextDouble();
	System.out.println();
	System.out.println("Enter width");
	double wt=sc.nextDouble();
	System.out.println("*******************************");
	
	
	//Rectangle
	Rectangle rt;
	if(ht==wt)
	{
		 rt=new Rectangle( ht,wt);
		rt. ComputeArea();
	}
	else
	{
		 rt=new Rectangle( ht);
		rt. ComputeArea();
	}
	rt.get();
	 System.out.println("Area of Rectangle :"+rt.area);
	 System.out.println("*******************************");

	//Square
	Square s=new Square(ht,wt);
	s.get();
	s.ComputeArea();
	 System.out.println("*******************************");
	
	//Triangle
	Triangle t=new Triangle(ht,wt);
    t.get();

    t.ComputeArea();
    System.out.println("*******************************");
	}
	


}
