package excercise1;

import java.util.Scanner;

class student{
	private int id;
	private String name;
	private String courseName;
	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getCourseName() {
		return courseName;
	}

	public void setCourseName(String courseName) {
		this.courseName = courseName;
	}

	
	
	public student(int id, String name, String courseName) {
		
		this.id = id;
		this.name=name;;
		this.courseName = courseName;
	}

	void showDetails()
	{
		System.out.println("Id : "+id);
		System.out.println("Name : "+name);
		System.out.println("Course Name  : "+courseName);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}
	

}


class  Hosteller extends student{
	private int roomRent;
	private int messFee;
	public Hosteller(int id, String name, String courseName, int messFee, int roomRent) {
		super(id, name, courseName);
		this.messFee = messFee;
		this.roomRent = roomRent;
	}
	int calculateHostelFee()
	{
		return messFee+roomRent;
	}
	
	
	

	
	
}
class CollegeBusGoers extends student{
	private int BusFee;

	public CollegeBusGoers(int id, String name, String courseName, int busFee) {
		super(id, name, courseName);
		BusFee = busFee;
	}

	
int displayBusFee()
{
	return BusFee;
}
	
	
}

public class mainClass {
	 Scanner sc =new Scanner(System.in);
static void disp()
{
	
}

	public static void main(String[] args) {
	Scanner sc=new Scanner(System.in);

	System.out.println("Enter Id :");
	int id=sc.nextInt();
	System.out.println("Enter your Name : ");
    String  name=sc.nextLine();
    sc.nextLine();
	System.out.println("Enter Course Name : ");
    String  cname=sc.nextLine();
		
		System.out.println("Enter 1 for Hosteller");
		System.out.println("Enter 2 for BusStudent");
		int input=sc.nextInt();
		
		if(input==1)
		{
			 
			
				System.out.println("Enter messfee");
			    int mess=sc.nextInt();
				System.out.println("Enter room rent");
				int room=sc.nextInt();
			Hosteller h=new Hosteller(id, name, cname, mess, room);
			
			
			h.showDetails();
			System.out.println("Hostel Fee : "+h.calculateHostelFee());
			
		}
		else if(input ==2)
		{
			
			System.out.println("Enter Busfee");
	        int bus=sc.nextInt();
			CollegeBusGoers c=new CollegeBusGoers(id, name, cname, bus);
		c.showDetails();
			System.out.println( "Bus fee : "+bus);
		}

	}
}


