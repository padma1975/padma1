package Code;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.swing.text.Segment;
public class Testcode2<Shipment> {
public static void main(String[] args) {
File file=new File("D:\\ZensarTest\\input.txt");
//System.out.println(file.getAbsolutePath());
Testcode2 shipmentManager = new Testcode2();
List<Testcode2> listShipment = shipmentManager.readShipmentDetails(file.getAbsolutePath());
System.out.println("List Shipment Data:"+listShipment);
}
public List<Testcode2> readShipmentDetails(String fileName) {
FileReader fileReader;
BufferedReader bufferedReader;
List<Testcode2> list = new ArrayList<>();
try {
fileReader = new FileReader(fileName);
bufferedReader=new BufferedReader(fileReader);
String line;
Testcode2 shipment;
while(bufferedReader.readLine() != null) {
shipment =new Testcode2();
line = bufferedReader.readLine();
String shipmentData[] =line.split(",");
System.out.println(shipmentData[0]+","+shipmentData[1]+","+shipmentData[2]+","+shipmentData[3]+","+shipmentData[4]+","+shipmentData[5]);
shipment.setId(Long.valueOf(shipmentData[0]));
shipment.setBookingNumber(shipmentData[1]);
shipment.setDepartureDate(new SimpleDateFormat("dd/MM/yyyy").parse(shipmentData[2]));
shipment.setArrivalDate(new SimpleDateFormat("dd/MM/yyyy").parse(shipmentData[3]));
shipment.setTotalWeight(Integer.parseInt(shipmentData[4]));
shipment.setStatus(shipmentData[5]);
list.add(shipment);
}
} catch (Exception e) {
// TODO Auto-generated catch block
e.printStackTrace();
}
return list;
}
private void setStatus(String string) {
	// TODO Auto-generated method stub
	
}
private void setTotalWeight(int parseInt) {
	// TODO Auto-generated method stub
	
}
private void setArrivalDate(Date parse) {
	// TODO Auto-generated method stub
	
}
private void setBookingNumber(String string) {
	// TODO Auto-generated method stub
	
}
private void setDepartureDate(Date parse) {
	// TODO Auto-generated method stub
	
}
private void setId(Long valueOf) {
	// TODO Auto-generated method stub
	
}
public List<Shipment> filterByStatus(List shipmentList,String status)
{
return null;
}
public void saveShipments(List<Shipment> shipmentList,String outputfile){
}
}

